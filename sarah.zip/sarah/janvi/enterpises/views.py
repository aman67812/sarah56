from django.shortcuts import render
from  django.http import HttpResponse
import smtplib
# Create your views here.
def index(request): 
         return render(request,"enterpises/home.html")
def contact(request):
  if request.method == 'POST':
     server = smtplib.SMTP("smtp.gmail.com", 587)
     content="""\Suject: hello
     hello"""
     server.ehlo()
     server.starttls()
     fr = "srhbhatnagar6789@gmail.com"
     server.login(fr, "sarah123@")
     server.sendmail(fr, "amanshukla5614@gmail.com", content)
     server.quit()
  return render(request,"enterpises/home.html")
